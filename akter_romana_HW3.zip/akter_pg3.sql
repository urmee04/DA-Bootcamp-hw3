#page 3 is reserved for SQL experimentation on Problem 3. 
#You're encouraged to experiment here but your final (tidy) answers must be on page 1. 
#TEMPORARY TABLEs are fun because you can query directly into them without constucting them first.
#Great for exploratory analysis.

Use da_bootcamp_akter;

DROP TEMPORARY TABLE IF EXISTS sales_data_all;

CREATE TEMPORARY TABLE sales_data_all (
item_id TEXT,
item_price DECIMAL(10,1),
item_description TEXT
);
INSERT INTO sales_data_all 
SELECT * 
FROM item_details;

SELECT * FROM sales_data_all;

SELECT count(*) FROM sales_data_all;




#Provide any other queries you used and wish to share. This is optional but hopefully valuable.
















