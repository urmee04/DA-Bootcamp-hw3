# Page 7 is reserved for creating function is_leap_year. 

DROP FUNCTION IF EXISTS is_leap_year;

DELIMITER $$
CREATE FUNCTION `is_leap_year`(
  birth_date Date
)
RETURNS bool   
READS SQL DATA
DETERMINISTIC
BEGIN
   DECLARE is_leap Date;
    IF((birth_date % 400 = 0) or
    (birth_date % 100<> 0) and
    (birth_date % 4 = 0)) THEN
    return 1;
   ELSE
   return 0;
END IF ;  
    
END$$
DELIMITER ;
